from gendiff_folder.progs import gendiff


def main():
    gendiff


if __name__ == '__main__':
    main()
