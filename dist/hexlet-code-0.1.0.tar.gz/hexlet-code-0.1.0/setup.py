# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff_folder', 'gendiff_folder.progs', 'gendiff_folder.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['generate_diff = gendiff_folder.scripts.gendiff_s:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Nurlan Khamzin',
    'author_email': 'khamzin1991@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
